# SocketDemo
This Demo project is for one to one chat by using socket.io.
