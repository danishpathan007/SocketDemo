//
//  NetworkMonitor.swift
//  Yapi
//
//  Created by Sunfocus Solutions on 06/09/23.
//

import Reachability


class NetworkHelper {
    static let shared = NetworkHelper()
    
    private let reachability = try! Reachability()
    
    var isInternetAvailable: Bool {
        return reachability.connection != .unavailable
    }
    
    private init() {
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        do {
            try reachability.startNotifier()
        } catch {
            print("Could not start reachability notifier")
        }
    }
    
    deinit {
        reachability.stopNotifier()
        NotificationCenter.default.removeObserver(self, name: .reachabilityChanged, object: reachability)
    }
    
    @objc func reachabilityChanged(note: Notification) {
        let reachability = note.object as! Reachability
        
        switch reachability.connection {
        case .wifi:
            print("Reachable via WiFi")
        case .cellular:
            print("Reachable via Cellular")
        case .unavailable:
            print("Network not reachable")
        case .none:
            print("Network not reachable")
        }
        
        NotificationCenter.default.post(name: .networkStatusChanged, object: isInternetAvailable)
    }
}

extension Notification.Name {
    static let networkStatusChanged = Notification.Name("NetworkStatusChanged")
}
