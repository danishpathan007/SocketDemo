//
//  ViewController.swift
//  Socket.Io_Demo
//
//  Created by Sunfocus Solutions on 11/09/23.
//

import UIKit

class ChatListViewController: UIViewController {

    private var socketIOManager = SocketIOManager.shared
    
    @IBOutlet weak var tableView:UITableView!{
        didSet{
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    
    private var chatList:[ChatData] = [] {
        didSet{
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        socketIOManager.socketDelegate = self
        socketIOManager.getAllChats()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            SocketIOManager.shared.emitWithObject(eventName: Listner.chatListing.rawValue, params: [
                "senderId": "64fea119752eed0b5350ebb2",
                "pageNumber": 1])
        }
    }
    
    
}

extension ChatListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ChatListTableViewCell") as? ChatListTableViewCell else {return UITableViewCell() }
        let chat = chatList[indexPath.row]
        cell.userNameLabel.text = chat.opponentUser.firstName
        cell.lastMessageLabel.text = chat.lastMessage?.message
        return cell
    }
        
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return chatList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}


extension ChatListViewController: SocketConnectionDelegate {
    func onSocketConnected() {
    
    }
    
    func onSocketDisconnected() {
        
    }
    
    func chatList(chatList: [ChatData]) {
        self.chatList = chatList
        print(chatList.count)
    }
    
    func fetchUsersChatList() {
        
    }
    
    
}
