import UIKit
import SocketIO
import ObjectMapper

//MARK:- Socket Connection Manager Protocol
protocol SocketConnectionDelegate: AnyObject {
    func onSocketConnected()
    func onSocketDisconnected()
    //func oldMessages(messages:[LastMessage])
    func chatList(chatList:[ChatData])
    // recivedMessage(message:LastMessage?)
    func fetchUsersChatList()
    //func roomOldMessages(messages:[LastMessage])
    //func roomRecivedMessage(message:LastMessage?)
}
/**
 SocketConnectionManager
 
 This Class manages the socket operations for ChatViewController
 
 - Author:
 Danish Khan
 
 - Date:
 11/09/2023
 */
class SocketIOManager{
    
    static let shared:SocketIOManager = SocketIOManager()
    
    var manager: SocketManager!
    var socket: SocketIOClient!
    
    weak var socketDelegate : SocketConnectionDelegate?
    
    private init() {
        
    }
    
    func initWithConnect() {
        manager = SocketManager(socketURL:  URL(string: "http://192.168.1.87:3000")!, config: [.log(false),.compress, .extraHeaders(["origin": "http://192.168.1.87:3000"])])
        
        socket = manager.defaultSocket
        
        socket.connect()
        
        socket.on(clientEvent: .connect) {data, ack in
            self.socketDelegate?.onSocketConnected()
            print("socket Connected")
            //if let user = CommonUtilities.getUserFromUserDefaults(){
            //}
            self.emitWithString(eventName: Events.socketJoin.rawValue, value: "64fea119752eed0b5350ebb2")
        }
        
        socket.on(clientEvent: .disconnect) { (data, ack) in
            self.socketDelegate?.onSocketDisconnected()
            print("socket disconnect")
        }
    }
    
    func getAllChats() {
        socket.on(Listner.chatListing.rawValue) {data, ack in
            print("ON Recive Message")
            if let dataStringJson = data[0] as? [String:Any] {
                if let dictArray = dataStringJson["data"] as? [[String:Any]] {
                    print("===========> Chat List <==============\n")
                    print(dictArray)
                    print("======================================\n\n\n")

                    var chatList:[ChatData] = []
                    for dict in dictArray {
                        chatList.append(ChatData(chatData: dict))
                    }
                    self.socketDelegate?.chatList(chatList: chatList)
                }
            }
        }
    }
    
    
    var localTimeZoneIdentifier: String { return TimeZone.current.identifier }
    

    func emitWithObject(eventName:String,params: [String : Any]) {
        SocketIOManager.shared.socket.emit(eventName, params)
    }
    
    func emitWithString(eventName:String,value: String) {
        SocketIOManager.shared.socket.emit(eventName, value)
    }
    
    
    func disconnectSocket(){
        socket.disconnect()
    }
    
    func reConnectSocket() {
        if !socket.status.active {
            socket.connect()
        }
    }
    
    func isSocketConnected() -> Bool {
        return socket.status.active
    }
}

enum Events: String{
    case socketJoin              = "join"
    case oldChatList             = "getChatUserList"
    case oldMessages             = "messageLoad"
    case sendMessage             = "sendMessage"
    case leaveChat               = "leave"
    case roomJoin                = "roomJoin"
    case roomLeave               = "roomLeave"
    case roomOldMessage          = "roomMessageLoad"
    case roomSendMessage         = "roomSendMessage"
    case getArchiveChatUserList  = "getArchiveChatUserList"
}

enum Listner: String{
    case chatListing             = "chatListing"
    
    
    case oldMessages             = "messageList"
    case reciveMessage           = "reciveMessage"
    case joinChat                = "joinMessage"
    case errorMessage            = "errorMessage"
    case roomOldMessage          = "roomMessageList"
    case roomReciveMessage       = "roomReciveMessage"
    case archiveChatUserList     = "archiveChatUserList"
    case fireUserListEvent       = "fireUserListEvent"
    case socketJoin              = "joinSocket"
}
