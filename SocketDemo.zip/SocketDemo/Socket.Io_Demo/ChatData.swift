//
//  ChatData.swift
//  iBeor
//
//  Created by Sunfocus Solutions on 18/04/22.
//

import UIKit
import SwiftyJSON

class ChatData: NSObject {
    
    var chatID: String?
    var senderId:String?
    var receiverId:String?
    var lastMessage: MessageData?
    
    var superlikedByOpponent: Bool = false
    var boostByOpponent: Bool = false
    var premiumPurchasedByOpponent: Bool = false
    var unreadMessageCount: Int = 0
    var timeStamp: Int = 0
    var isTyping: Bool = false
    var archiveStatusForMe: Bool = false
    var isDeletedChat: Bool = false
    var isMessageRequestAccepted: Bool = false
    var isPrivateMessage: Bool = false
    var isMatchViewed: Bool = false
    var blockedStatus: Bool = false
    var whoBlocked: String = ""
    var opponentUser = UserData()
    
    override init() {
        
    }
    
    init(json: JSON) {
        self.chatID    = json["_id"].stringValue
      
        if json["lastMessage"].exists() {
            self.lastMessage = MessageData(messageData: json["lastMessage"], key: "")
        }
               
        
        
        if json["senderId"].exists() {
            self.senderId = json["senderId"].stringValue
        }
        
        if json["receiverId"].exists() {
            self.receiverId = json["receiverId"].stringValue
        }
        
        
        if json["unreadMessageCount"].exists() {
           
        }
        if json["isMessageRequestAccepted"].exists() {
            self.isMessageRequestAccepted = json["isMessageRequestAccepted"].boolValue
        }
        
        if json["isPrivateMessage"].exists() {
            self.isPrivateMessage = json["isPrivateMessage"].boolValue
        }
        if json["blockedStatus"].exists() {
            self.blockedStatus = json["blockedStatus"].boolValue
        }
        if json["isDeletedChat"].exists() {
            self.isDeletedChat = json["isDeletedChat"].boolValue
        }
        if self.blockedStatus == true {
            if json["whoBlocked"].exists() {
                self.whoBlocked = json["whoBlocked"].stringValue
            }
        }
       
        if json["typingStatus"].exists() {
            if json["typingStatus"]["\(self.opponentUser.userID)"].exists() {
                self.isTyping = json["typingStatus"]["\(self.opponentUser.userID)"].boolValue
            }
        }
        
        if json["updatedAt"].exists() {
            self.timeStamp = json["updatedAt"].intValue
        }
    }
    
    init(chatData: [String: Any]) {
        self.chatID = chatData["_id"] as? String
        
        if let lastMessageData = chatData["lastMessage"] as? [String: Any] {
            self.lastMessage = MessageData(messageData: lastMessageData, key: "")
        }
        
        
        if let opponentUserData = chatData["opponentUserData"] as? [String: Any] {
            self.opponentUser = UserData(userData: opponentUserData)
        }
        
        
        self.senderId = chatData["senderId"] as? String
        self.receiverId = chatData["receiverId"] as? String
        
        if let unreadMessageCount = chatData["unreadMessageCount"] as? Int {
            self.unreadMessageCount = unreadMessageCount
        }
        
        if let isMessageRequestAccepted = chatData["isMessageRequestAccepted"] as? Bool {
            self.isMessageRequestAccepted = isMessageRequestAccepted
        }
        
        if let isPrivateMessage = chatData["isPrivateMessage"] as? Bool {
            self.isPrivateMessage = isPrivateMessage
        }
        
        if let blockedStatus = chatData["blockedStatus"] as? Bool {
            self.blockedStatus = blockedStatus
        }
        
        if let isDeletedChat = chatData["isDeletedChat"] as? Bool {
            self.isDeletedChat = isDeletedChat
        }
        
        if self.blockedStatus == true {
            self.whoBlocked = chatData["whoBlocked"] as? String ?? ""
        }
        
        if let typingStatusData = chatData["typingStatus"] as? [String: Any],
           let typingStatusValue = typingStatusData["\(self.opponentUser.userID)"] as? Bool {
            self.isTyping = typingStatusValue
        }
        
        if let updatedAt = chatData["updatedAt"] as? Int {
            self.timeStamp = updatedAt
        }
    }
    
}

class UserData: NSObject {
    var userID: String?
    var firstName: String?
   
    
    override init() {
        
    }
    
    init(json: JSON, userId: String) {
        self.userID = userId
        self.firstName = json["firstName"].stringValue

    }
    
    init(userData: [String:Any]) {
        self.userID = userData["userId"] as? String ?? nil
        self.firstName = userData["firstName"] as? String ?? nil
    }
    
    
}

class MessageData: NSObject {
    var message: String?
    var messageTime: Int?
    var messageType: Int?
    var opponentID: String?
    var readStatus: Bool = false
    var senderID: String?
    var messageID: String?
    var heartLikeMessage: Bool = false
    var fileName: String?
   
    override init() {
        
    }
    
    init(messageData: JSON, key: String) {
        self.messageID = key
        self.message = messageData["message"].stringValue
        self.messageTime = messageData["messageTime"].intValue
        self.messageType = messageData["messageType"].intValue
        self.readStatus = messageData["readStatus"].boolValue
        self.opponentID = messageData["opponentID"].stringValue
        self.senderID = messageData["senderID"].stringValue
        self.fileName = messageData["fileName"].stringValue
        self.heartLikeMessage = messageData["heartLikeMessage"].boolValue
    }
    
    init(messageData: [String:Any], key: String) {
        self.messageID = key
        self.message = messageData["message"] as? String ?? nil
        self.messageTime = messageData["messageTime"] as? Int ?? nil
        self.messageType = messageData["messageType"] as? Int ?? nil
        self.readStatus = messageData["readStatus"] as? Bool ?? false
        self.opponentID = messageData["opponentID"] as? String ?? nil
        self.senderID = messageData["senderID"] as? String ?? nil
        self.fileName = messageData["fileName"] as? String ?? nil
        self.heartLikeMessage = messageData["heartLikeMessage"] as? Bool ?? false
    }
    
}
